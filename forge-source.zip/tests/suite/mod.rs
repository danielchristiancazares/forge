//! Test suite module declarations
//!
//! Add new test modules here as the test suite grows.

mod markdown;
mod message;
mod provider;
